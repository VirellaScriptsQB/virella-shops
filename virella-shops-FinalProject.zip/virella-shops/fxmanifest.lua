fx_version 'cerulean'
game 'gta5'

description 'Virella-Shops'
author 'YourName'
version '1.0.0'

-- Dependencies for this script
dependencies {
    'qb-core',        -- Core framework dependency
    'qb-menu',        -- Menu system dependency
    'qb-input',       -- Input system dependency for quantity selection
    'okokBanking'     -- Banking system for payment transactions
}

-- Client-side scripts
client_scripts {
    'config.lua',     -- Configuration file for shop settings and points
    'client.lua'      -- Main client-side script for interaction and UI
}

-- Server-side scripts
server_scripts {
    '@oxmysql/lib/MySQL.lua',  -- MySQL library for database interaction (if needed)
    'config.lua',              -- Configuration file for shared settings
    'server.lua'               -- Main server-side script for handling purchases and payments
}

-- Shared resources (if needed)
shared_script 'config.lua'

-- UI dependencies (optional, add if you have HTML/CSS/JS resources for the shops)
ui_page 'html/index.html'

files {
    'html/index.html',
    'html/css/style.css',
    'html/js/script.js'
}

-- Lua version support
lua54 'yes'
