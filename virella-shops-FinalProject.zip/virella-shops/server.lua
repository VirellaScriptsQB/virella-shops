local QBCore = exports['qb-core']:GetCoreObject()

-- Helper function to get shop by pointKey
function GetShopByKey(pointKey)
    for _, category in pairs(Config.ShopPoints) do
        if category[pointKey] then
            return category[pointKey]
        end
    end
    return nil
end

-- Helper function to get item from shop items
function GetItemByName(items, itemName)
    for _, item in ipairs(items) do
        if item.name == itemName then
            return item
        end
    end
    return nil
end

-- Calculate tax amount based on shop or default tax rate
function CalculateTax(pointKey, totalPrice)
    local taxRate = Config.TaxSystem.shopTaxOverrides[pointKey] or Config.TaxSystem.defaultTaxRate
    return totalPrice * taxRate
end

-- Handle item purchases from the client
RegisterNetEvent('shopPoints:handlePurchase', function(paymentMethod, pointKey, itemName, itemLabel, totalPrice, quantity)
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    local shop = GetShopByKey(pointKey)

    if not shop then
        TriggerClientEvent('QBCore:Notify', src, "Invalid shop point!", "error")
        return
    end

    local item = GetItemByName(shop.items, itemName)
    if not item then
        TriggerClientEvent('QBCore:Notify', src, "This item is not available in the shop!", "error")
        return
    end

    -- Check if enough stock is available
    if item.stock and item.stock < quantity then
        TriggerClientEvent('QBCore:Notify', src, "Not enough stock available for this item.", "error")
        return
    end

    -- Handle payment based on selected method
    local success = false

    if paymentMethod == 'cash' then
        if player.Functions.RemoveMoney('cash', totalPrice) then
            success = true
        else
            TriggerClientEvent('QBCore:Notify', src, "You don't have enough cash!", "error")
        end
    elseif paymentMethod == 'bank' then
        local bankBalance = player.PlayerData.money['bank']
        if bankBalance >= totalPrice then
            player.Functions.RemoveMoney('bank', totalPrice)
            success = true
        else
            TriggerClientEvent('QBCore:Notify', src, "You don't have enough funds in your bank account!", "error")
        end
    end

    -- Finalize the purchase if successful
    if success then
        -- Give the player the correct quantity of items
        player.Functions.AddItem(itemName, quantity)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[itemName], 'add')
        TriggerClientEvent('QBCore:Notify', src, "You bought " .. quantity .. "x " .. itemLabel .. " for $" .. totalPrice .. ".", "success")

        -- Update stock if enabled
        if Config.StockSystem.enabled then
            item.stock = item.stock - quantity
        end

        -- Apply tax deduction
        Citizen.SetTimeout(2000, function()  -- Delay to simulate tax processing
            local taxAmount = CalculateTax(pointKey, totalPrice)
            local bankBalance = player.PlayerData.money['bank']

            if bankBalance >= taxAmount then
                player.Functions.RemoveMoney('bank', taxAmount)
                TriggerClientEvent('QBCore:Notify', src, "A tax of $" .. string.format("%.2f", taxAmount) .. " has been deducted from your bank account.", "info")
            else
                TriggerClientEvent('QBCore:Notify', src, "You don't have enough funds for the tax deduction!", "error")
            end
        end)
    end
end)

-- Restock system (if enabled)
if Config.StockSystem.enabled then
    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(Config.StockSystem.restockTime * 1000) -- Restock interval in seconds

            for _, category in pairs(Config.ShopPoints) do
                for _, shop in pairs(category) do
                    for _, item in ipairs(shop.items) do
                        if item.stock and item.stock < Config.StockSystem.maxStock[item.name] then
                            item.stock = Config.StockSystem.maxStock[item.name]
                        end
                    end
                end
            end

            print("[Virella-Shops] Stock has been replenished.")
        end
    end)
end
