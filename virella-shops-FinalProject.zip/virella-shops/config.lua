-- Configuration for Virella-Shops

Config = {}

-- General Interaction Settings
Config.Interaction = {
    key = 38,          -- Default interaction key ('E')
    distance = 2.5     -- Distance within which interaction is possible
}

-- Global Settings
Config.Settings = {
    shopAlwaysOpen = true,  -- If true, all shops will always stay open regardless of hours
    useRealTime = false     -- Use real-time instead of game time for shop hours
}

-- **Tax System Configuration**
Config.TaxSystem = {
    defaultTaxRate = 0.1,  -- Default tax rate (10%)
    shopTaxOverrides = {
        -- Define tax overrides for specific shops here. Example:
        -- ["weapon_shop_1"] = 0.2  -- 20% tax for this weapon shop
    },
    exemptJobs = { "police", "ems" },  -- Jobs exempt from tax deductions
    taxApplyDelay = 2000,  -- Delay (in milliseconds) before tax is deducted after a purchase
}

-- Dynamic Discounts
Config.DynamicDiscounts = {
    enabled = true,
    events = {
        ["holiday"] = 0.2,  -- 20% discount during holidays
        ["vip_member"] = 0.15  -- 15% discount for VIP members
    }
}

-- Player Reputation System
Config.Reputation = {
    enabled = true,
    reputationLevels = {
        { level = 1, discount = 0.05 },  -- 5% discount for level 1
        { level = 2, discount = 0.1 },   -- 10% discount for level 2
    }
}

-- Loyalty Rewards
Config.LoyaltyRewards = {
    enabled = true,
    pointsPerPurchase = 1,
    rewards = {
        { points = 10, rewardItem = "coupon_discount" },
        { points = 50, rewardItem = "exclusive_item" }
    }
}

-- Stock System
Config.StockSystem = {
    enabled = true,
    restockTime = 3600,  -- Restock every hour
    maxStock = {
        ["pistol"] = 5,
        ["water_bottle"] = 50
    }
}

-- Random Shop Sales
Config.RandomSales = {
    enabled = true,
    itemsOnSale = {
        { item = "cola", discount = 0.3, duration = 600 }  -- 30% off for 10 minutes
    }
}

-- Gang Shop Protection Fees
Config.GangShopProtection = {
    enabled = true,
    feeAmount = 100  -- $100 fee for non-gang members
}

-- Time-Limited Items
Config.TimeLimitedItems = {
    enabled = true,
    items = {
        { name = "rare_item", availableFrom = 20, availableUntil = 4 }  -- Available from 8 PM to 4 AM
    }
}

-- Player Shop Ownership
Config.PlayerShops = {
    enabled = true,
    maxShopsPerPlayer = 1
}

-- Entry Requirements for Shops
Config.EntryRequirements = {
    enabled = true,
    shopRequirements = {
        ["exclusive_shop"] = { requiredItems = { "vip_card" } }
    }
}

-- Shop Announcements
Config.ShopAnnouncements = {
    enabled = true,
    interval = 1800,  -- Every 30 minutes
    messages = {
        "Check out our latest deals at the general store!",
        "Limited-time offers available at the weapon shop!"
    }
}

-- Define valid ped models for shop NPCs
Config.ValidPedModels = {
    "mp_m_shopkeep_01",
    "s_m_y_ammucity_01",
    "g_m_y_mexgoon_03",
    "s_m_y_cop_01"
}

-- Marked Bills Configuration (used for special shops)
Config.MarkedBillsCurrency = "markedbills"

-- Blip Settings
Config.Blips = {
    enabled = true,
    sprite = 52,         -- Default shop blip sprite
    color = 2,           -- Blip color (Green)
    scale = 0.8          -- Blip scale
}

-- **Shop Points Configuration**
Config.ShopPoints = {
    -- ***General Shops***
    general_shops = {
        ["general_store_1"] = {
            location = vector3(116.47, -1089.09, 29.23),
            pedModel = "mp_m_shopkeep_01",
            interactText = "Browse Items",
            currency = "cash",  -- Accepts cash payment
            blip = { enabled = true, name = "General Store" },
            openHours = { start = 0, finish = 0 },  -- Always open if shopAlwaysOpen is true
            items = {
                { name = "water_bottle", label = "Water Bottle", price = 5, stock = 50 },
                { name = "sandwich", label = "Sandwich", price = 10, stock = 30 }
            }
        }
    },

    -- ***Weapon Shops***
    weapon_shops = {
        ["weapon_shop_1"] = {
            location = vector3(1692.41, 3759.17, 34.705),
            pedModel = "s_m_y_ammucity_01",
            interactText = "Browse Weapons",
            currency = "markedbills",  -- Accepts marked bills for payment
            blip = { enabled = false, name = "Weapon Shop" },
            openHours = { start = 10, finish = 22 },  -- Shop opens from 10 AM to 10 PM
            items = {
                { name = "pistol", label = "Pistol", price = 1500, stock = 5 },
                { name = "pistol_ammo", label = "Pistol Ammo", price = 100, stock = 100 }
            }
        }
    },

    -- ***Gang Shops***
    gang_shops = {
        ["gang_shop_lostmc"] = {
            location = vector3(2450.32, 4969.13, 45.57),
            pedModel = "g_m_y_mexgoon_03",
            interactText = "Gang Supplies",
            currency = "cash",  -- Cash payment
            requiredGang = "lostmc",  -- Restricted to the "Lost MC" gang
            protectionFee = 0.05,  -- 5% extra fee if not in the gang
            blip = { enabled = false },  -- No blip for gang shop
            openHours = { start = 18, finish = 4 },  -- Shop opens at 6 PM and closes at 4 AM
            items = {
                { name = "lockpick", label = "Lockpick", price = 50, stock = 20 },
                { name = "handcuffs", label = "Handcuffs", price = 150, stock = 10 }
            }
        }
    },

    -- ***Job-Restricted Shops***
    job_shops = {
        ["police_shop"] = {
            location = vector3(451.75, -980.16, 30.69),
            pedModel = "s_m_y_cop_01",
            interactText = "Police Equipment",
            currency = "bank",  -- Payment through bank account
            requiredJob = "police",  -- Restricted to police job
            blip = { enabled = false, name = "Police Armory" },
            openHours = { start = 6, finish = 22 },  -- Open from 6 AM to 10 PM
            items = {
                { name = "pistol_ammo", label = "Pistol Ammo", price = 100, stock = 200 },
                { name = "flashlight", label = "Flashlight", price = 50, stock = 50 }
            }
        }
    }
}
