-- Client-side Script for Virella-Shops with Quantity Selection via qb-input

local QBCore = exports['qb-core']:GetCoreObject()
local ShopPoints = Config.ShopPoints
local shopAlwaysOpen = Config.Settings.shopAlwaysOpen
local useRealTime = Config.Settings.useRealTime
local textDrawDistance = 10.0

-- Helper function to check if a shop is open based on real or game time
function IsShopOpen(shop)
    if shopAlwaysOpen then return true end

    local hour
    if useRealTime then
        local realTime = os.date("*t")
        hour = realTime.hour
    else
        hour = GetClockHours()
    end

    return (shop.openHours.start <= shop.openHours.finish and hour >= shop.openHours.start and hour < shop.openHours.finish) or
           (shop.openHours.start > shop.openHours.finish and (hour >= shop.openHours.start or hour < shop.openHours.finish))
end

-- Validate if the ped model exists in the valid ped models list
function IsValidPedModel(model)
    for _, validModel in ipairs(Config.ValidPedModels) do
        if validModel == model then
            return true
        end
    end
    return false
end

-- Spawn Peds and Blips for Shop Points
Citizen.CreateThread(function()
    for category, shops in pairs(ShopPoints) do
        for pointKey, shop in pairs(shops) do
            if IsValidPedModel(shop.pedModel) then
                RequestModel(shop.pedModel)

                while not HasModelLoaded(shop.pedModel) do
                    Citizen.Wait(10)
                end

                local ped = CreatePed(4, shop.pedModel, shop.location.x, shop.location.y, shop.location.z - 1.0, 0.0, false, true)
                SetEntityInvincible(ped, true)
                FreezeEntityPosition(ped, true)
                SetBlockingOfNonTemporaryEvents(ped, true)
            end

            if Config.Blips.enabled and shop.blip and shop.blip.enabled then
                local blip = AddBlipForCoord(shop.location.x, shop.location.y, shop.location.z)
                SetBlipSprite(blip, Config.Blips.sprite)
                SetBlipDisplay(blip, 4)
                SetBlipScale(blip, Config.Blips.scale)
                SetBlipColour(blip, Config.Blips.color)
                SetBlipAsShortRange(blip, true)
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentSubstringPlayerName(shop.blip.name)
                EndTextCommandSetBlipName(blip)
            end
        end
    end
end)

-- Draw 3D text above ped
function Draw3DText(coords, text)
    local onScreen, _x, _y = World3dToScreen2d(coords.x, coords.y, coords.z + 1.0)
    local camCoords = GetGameplayCamCoords()
    local distance = #(camCoords - coords)

    if distance < textDrawDistance then
        local scale = 0.6 / distance
        if scale < 0.3 then scale = 0.3 end

        if onScreen then
            SetTextScale(scale, scale)
            SetTextFont(4)
            SetTextProportional(1)
            SetTextColour(255, 255, 255, 215)
            SetTextCentre(1)
            SetTextOutline()
            BeginTextCommandDisplayText("STRING")
            AddTextComponentSubstringPlayerName(text)
            EndTextCommandDisplayText(_x, _y)
        end
    end
end

-- Interaction Loop
Citizen.CreateThread(function()
    while true do
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        local nearAnyPoint = false

        for category, shops in pairs(ShopPoints) do
            for pointKey, shop in pairs(shops) do
                local distance = #(playerCoords - shop.location)

                if distance <= Config.Interaction.distance then
                    nearAnyPoint = true

                    if not IsShopOpen(shop) then
                        Draw3DText(shop.location, "Shop is currently closed")
                    else
                        Draw3DText(shop.location, "[E] " .. shop.interactText)
                        if IsControlJustReleased(0, Config.Interaction.key) then
                            TriggerEvent('shopPoints:openMenu', pointKey)
                        end
                    end

                    break
                end
            end
        end

        if not nearAnyPoint then
            Citizen.Wait(500)
        else
            Citizen.Wait(0)
        end
    end
end)

-- Open shop menu with items from config.lua
RegisterNetEvent('shopPoints:openMenu', function(pointKey)
    local shop = GetShopByKey(pointKey)
    if not shop then
        Notify("Invalid shop point!", "error")
        return
    end

    local menuItems = {}

    for _, item in ipairs(shop.items) do
        table.insert(menuItems, {
            header = item.label .. " - $" .. item.price,
            txt = "Buy this item",
            params = {
                event = 'shopPoints:selectQuantity',
                args = { pointKey = pointKey, itemName = item.name, itemLabel = item.label, price = item.price, maxStock = item.stock }
            }
        })
    end

    exports['qb-menu']:openMenu(menuItems)
end)

-- Event to select quantity via qb-input
RegisterNetEvent('shopPoints:selectQuantity', function(data)
    local input = exports['qb-input']:ShowInput({
        header = "Select Quantity",
        submitText = "Confirm",
        inputs = {
            {
                text = "Enter Quantity",
                name = "quantity",
                type = "number",
                isRequired = true,
                default = "1"
            }
        }
    })

    if input and input.quantity then
        local quantity = tonumber(input.quantity)
        if quantity and quantity > 0 and quantity <= data.maxStock then
            local totalPrice = data.price * quantity
            TriggerEvent('shopPoints:choosePayment', {
                pointKey = data.pointKey,
                itemName = data.itemName,
                itemLabel = data.itemLabel,
                price = totalPrice,
                quantity = quantity
            })
        else
            Notify("Invalid quantity or exceeds available stock.", "error")
        end
    else
        Notify("Quantity selection canceled.", "error")
    end
end)

-- Event to handle choosing payment method
RegisterNetEvent('shopPoints:choosePayment', function(data)
    local menuItems = {
        {
            header = "Select Payment Method",
            isMenuHeader = true
        },
        {
            header = "Pay with Cash",
            txt = "Purchase using cash",
            params = {
                event = 'shopPoints:purchaseItem',
                args = { paymentMethod = 'cash', pointKey = data.pointKey, itemName = data.itemName, itemLabel = data.itemLabel, price = data.price, quantity = data.quantity }
            }
        },
        {
            header = "Pay with Bank",
            txt = "Purchase using bank account",
            params = {
                event = 'shopPoints:purchaseItem',
                args = { paymentMethod = 'bank', pointKey = data.pointKey, itemName = data.itemName, itemLabel = data.itemLabel, price = data.price, quantity = data.quantity }
            }
        }
    }

    exports['qb-menu']:openMenu(menuItems)
end)

-- Event to handle item purchases
RegisterNetEvent('shopPoints:purchaseItem', function(data)
    TriggerServerEvent('shopPoints:handlePurchase', data.paymentMethod, data.pointKey, data.itemName, data.itemLabel, data.price, data.quantity)
end)

-- Helper function to get shop by pointKey
function GetShopByKey(pointKey)
    for _, category in pairs(ShopPoints) do
        if category[pointKey] then
            return category[pointKey]
        end
    end
    return nil
end

-- Notify the player
RegisterNetEvent('shopPoints:notify', function(message, type)
    Notify(message, type)
end)

-- Function to display notifications using QBCore
function Notify(msg, type)
    exports['qb-core']:Notify(msg, type or 'success')
end
